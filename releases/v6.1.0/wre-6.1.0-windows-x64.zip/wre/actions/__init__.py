"""Actions package — handlers registered into rpc.py's ACTIONS table."""
